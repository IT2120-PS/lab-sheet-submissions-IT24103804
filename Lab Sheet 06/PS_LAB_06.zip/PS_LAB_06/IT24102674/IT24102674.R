setwd("C:\\Users\\SHAM\\Desktop\\PS_LAB_06\\IT24102674")

#LAB 06 - EXERCISE
#Question 01
# i) Binomial Distribution
# ii) Probability at atleast 47 students passed
1-pbinom(46, 50, 0.85, lower.tail = TRUE)
 #or else
pbinom(46, 50, 0.85, lower.tail = FALSE)

#Question 02
# i) number of customer calls received per hour
# ii) Poisson Distrinution
# iii)
dpois(15,12)